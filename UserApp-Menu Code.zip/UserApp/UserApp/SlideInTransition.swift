//
//  SlideInTransition.swift
//  UserApp
//
//  Created by eAlphaMac2 on 26/12/20.
//

import UIKit

class SlideInTransition: NSObject, UIViewControllerAnimatedTransitioning {
    
    var ispresenting = false
    let dimmingView = UIView()
    func transitionDuration(using transitionContext: UIViewControllerContextTransitioning?) -> TimeInterval {
        0.4
    }
    
    func animateTransition(using transitionContext: UIViewControllerContextTransitioning) {
        let toViewController = transitionContext.viewController(forKey: .to)
        let fromViewController = transitionContext.viewController(forKey: .from)
        
        let containerView = transitionContext.containerView
        let finalwidth = (toViewController?.view.bounds.width)! * 0.8
        let finalHeight = toViewController?.view.bounds.height
        
        if ispresenting {
            // Add dimming view
            dimmingView.alpha = 0.0
            dimmingView.backgroundColor = .black
            containerView.addSubview(dimmingView)
            dimmingView.frame = containerView.bounds
            
            // Add menu View Controller to Container
            containerView.addSubview((toViewController?.view)!)
            
            // init frame off the screen
            toViewController?.view.frame = CGRect(x: -finalwidth, y: 0, width: finalwidth, height: finalHeight!)
            
        }
        // Move on screen.
        let transform = {
            self.dimmingView.alpha = 0.5
            toViewController!.view.transform = CGAffineTransform(translationX: finalwidth, y: 0)
        }
        
        // Animate back off screen.
        let identity = {
            self.dimmingView.alpha = 0.0
            fromViewController?.view.transform = .identity
            
        }
        
        // Animate of the transition
        let duration = transitionDuration(using: transitionContext)
        let isCancelled = transitionContext.transitionWasCancelled
        UIView.animate(withDuration: duration, animations: { self.ispresenting ? transform() : identity() })
        { (_) in
            transitionContext.completeTransition(!isCancelled)
        }
        
        
    }
    

}
