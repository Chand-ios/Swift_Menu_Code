//
//  ViewController.swift
//  UserApp
//
//  Created by eAlphaMac2 on 26/12/20.
//

import UIKit

class HomeViewController: UIViewController {

    let transition = SlideInTransition()
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func menuAction(_ sender: Any) {
        let navVC = self.storyboard?.instantiateViewController(identifier: "MenuViewController") as! MenuViewController
        navVC.modalPresentationStyle = .overCurrentContext
        navVC.transitioningDelegate = self
        //self.navigationController?.pushViewController(navVC, animated: true)
        present(navVC, animated: true)
    }
    

    
}

extension HomeViewController : UIViewControllerTransitioningDelegate {
    func animationController(forPresented presented: UIViewController, presenting: UIViewController, source: UIViewController) -> UIViewControllerAnimatedTransitioning? {
        transition.ispresenting = true
        return transition
    }
    
    func animationController(forDismissed dismissed: UIViewController) -> UIViewControllerAnimatedTransitioning? {
        transition.ispresenting = false
        return transition
    }
}

