//
//  MenuViewController.swift
//  UserApp
//
//  Created by eAlphaMac2 on 26/12/20.
//

import UIKit

class MenuViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {
    
    var namesArr = ["Home","My Profile","Offers","My Orders","Wishlist","Delivery Address","Notifications","About App","Contact Us","Logout"]
    var imgArr = ["Home","My Profile","Offers","My Orders","Wishlist","Delivery Address","Notifications","About App","Contact Us","Logout"]

    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return namesArr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "MenuTableViewCell", for: indexPath as IndexPath) as! MenuTableViewCell
        
        cell.nameLbl.text = namesArr[indexPath.row]
        
    return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        dismiss(animated: true)
    }
    
    
}
